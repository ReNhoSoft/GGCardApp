import { getTechItemsByTag } from "./techItemTagService.js";

const route = {
    get: getTechItemsByTag
}

export default route;