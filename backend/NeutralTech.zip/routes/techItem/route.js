import { getTechItem } from "./techItemService.js";

const route = {
    get: getTechItem
}

export default route