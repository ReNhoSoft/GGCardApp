import { DynamoDBClient } from "@aws-sdk/client-dynamodb";
import { DynamoDBDocumentClient, GetCommand, QueryCommand, BatchGetCommand } from "@aws-sdk/lib-dynamodb";

const client = new DynamoDBClient({});
const docClient = DynamoDBDocumentClient.from(client);

const getTechItemTagsByCategory = async (category) => {
  if(!category) {
    return null;
  }
  const command = new QueryCommand({
    TableName:"tech-item-tags",
    KeyConditionExpression: "category = :category",
    ExpressionAttributeValues: {
      ":category":category
    }
  });
  
  const response = await docClient.send(command);
  if(response && response.Items) {
    return response.Items;
  }

  return null;
};

const queryTechItemsTag = async (category, name) => {
  const command = new GetCommand({
    TableName: "tech-item-tags",
    Key: {
      category: category,
      name: name
    },
  });
  
  const response = await docClient.send(command);
  if(response && response.Item) {
    return response.Item;
  }

  return null;
};

const getTechItems = async (techItemIds) => {
  const command = new BatchGetCommand({
    RequestItems: {
      "tech-items": {
        Keys: techItemIds.map((id) => {return {
          id
        }}),
      },
    },
  });

  const response = await docClient.send(command);
  if (response && response.Responses) {
    return response.Responses;
  }

  return null;
};

const queryTechItem = async (techItemId) => {
  const command = new QueryCommand({
    TableName:"tech-items",
    KeyConditionExpression: "id = :id",
    ExpressionAttributeValues: {
      ":id":techItemId
    }
  });
  
  const response = await docClient.send(command);
  if(response && response.Items && response.Items.length > 0) {
    return response.Items[0];
  }

  return null;
}

const putTechItem = async (techItem) => {
  const command = new PutCommand({
    Item: techItem,
    TableName: "tech-items",
  });
  const response = await docClient.send(command);
  if(response.httpStatusCode == 200) {
    return "Succesfully added item"
  }
  throw new Error("Unable to create item for unknown reasons");
}


export { queryTechItemsTag, getTechItemTagsByCategory, getTechItems, queryTechItem, putTechItem }